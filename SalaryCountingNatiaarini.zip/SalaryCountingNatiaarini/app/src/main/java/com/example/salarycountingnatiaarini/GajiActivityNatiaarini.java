package com.example.salarycountingnatiaarini;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GajiActivityNatiaarini extends AppCompatActivity {
    EditText etNik, etNama, etGajiPokok, etTunjanganJabatan, etHariKerja;
    EditText etTunjanganMakan, etTunjanganTransport, etGajiKotor, etGajiBersih;
    Button btnHitung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gaji_natiaarini);

        // Menghubungkan komponen dengan ID yang ada di file XML
        etNik = findViewById(R.id.etNik);
        etNama = findViewById(R.id.etNama);
        etGajiPokok = findViewById(R.id.etGajiPokok);
        etTunjanganJabatan = findViewById(R.id.etTunjanganJabatan);
        etHariKerja = findViewById(R.id.etHariKerja);
        etTunjanganMakan = findViewById(R.id.etTunjanganMakan);
        etTunjanganTransport = findViewById(R.id.etTunjanganTransport);
        etGajiKotor = findViewById(R.id.etGajiKotor);
        etGajiBersih = findViewById(R.id.etGajiBersih);
        btnHitung = findViewById(R.id.btnHitung);

        // Aksi ketika tombol HITUNG diklik
        btnHitung.setOnClickListener(v -> {
            try {
                String sHari = etHariKerja.getText().toString();
                String sPokok = etGajiPokok.getText().toString();
                String sJabatan = etTunjanganJabatan.getText().toString();

                // Validasi jika ada form utama yang kosong
                if (sHari.isEmpty() || sPokok.isEmpty() || sJabatan.isEmpty()) {
                    Toast.makeText(this, "Silakan isi data dengan lengkap!", Toast.LENGTH_SHORT).show();
                    return;
                }

                double hari = Double.parseDouble(sHari);
                double pokok = Double.parseDouble(sPokok);
                double jabatan = Double.parseDouble(sJabatan);

                // Rumus Perhitungan Gaji
                double tMakan = hari * 10000;
                double tTrans = hari * 5000;
                double gKotor = pokok + jabatan + tMakan + tTrans;
                double pajak = 0.10 * gKotor;
                double gBersih = gKotor - pajak;

                // Menampilkan hasil perhitungan ke kolom EditText di bawah
                etTunjanganMakan.setText(String.valueOf(tMakan));
                etTunjanganTransport.setText(String.valueOf(tTrans));
                etGajiKotor.setText(String.valueOf(gKotor));
                etGajiBersih.setText(String.valueOf(gBersih));

            } catch (Exception e) {
                Toast.makeText(this, "Terjadi kesalahan format angka!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}