package com.example.salarycountingnatiaarini;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivityNatiaarini extends AppCompatActivity {
    Button btnGajiPegawai, btnPetunjuk, btnTentang, btnExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_natiaarini);

        btnGajiPegawai = findViewById(R.id.btnGajiPegawai);
        btnPetunjuk = findViewById(R.id.btnPetunjuk);
        btnTentang = findViewById(R.id.btnTentang);
        btnExit = findViewById(R.id.btnExit);

        btnGajiPegawai.setOnClickListener(v -> startActivity(new Intent(this, GajiActivityNatiaarini.class)));
        btnPetunjuk.setOnClickListener(v -> startActivity(new Intent(this, PetunjukActivityNatiaarini.class)));
        btnTentang.setOnClickListener(v -> startActivity(new Intent(this, TentangActivityNatiaarini.class)));

        btnExit.setOnClickListener(v -> {
            finishAffinity();
            System.exit(0);
        });
    }
}