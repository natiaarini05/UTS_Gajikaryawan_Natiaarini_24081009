package com.example.salarycountingnatiaarini;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class PetunjukActivityNatiaarini extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petunjuk_natiaarini);
        Button btnKembali = findViewById(R.id.btnKembaliPetunjuk);
        if(btnKembali != null) btnKembali.setOnClickListener(v -> finish());
    }
}
