package com.example.salarycountingnatiaarini;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class TentangActivityNatiaarini extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentang_natiaarini);
        Button btnKembali = findViewById(R.id.btnKembaliTentang);
        if(btnKembali != null) btnKembali.setOnClickListener(v -> finish());
    }
}